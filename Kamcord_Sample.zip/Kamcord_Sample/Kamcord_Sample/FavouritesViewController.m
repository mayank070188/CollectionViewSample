//
//  FavouritesViewController.m
//  Kamcord_Sample
//
//  Created by Mayank Mathur on 8/20/16.
//  Copyright © 2016 Mayank Mathur. All rights reserved.
//

#import "FavouritesViewController.h"
#import "VideoViewController.h"
#import "Constants.h"
#import "MyLayout.h"

@interface FavouritesViewController ()

@end

@implementation FavouritesViewController
@synthesize cardArray;

static NSString * const reuseIdentifier = @"Cell";

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Custom class for adjust the distance between the cells in both devices.
    MyLayout *space = [[MyLayout alloc]init];
    self.collectionView.collectionViewLayout = space;
    
    cardArray = [[NSMutableArray alloc]init];
    
    // fetched feeds
    [self sendRequest:FEEDURL withNextPageFlag:0];
    
}

-(void)sendRequest:(NSString*)url withNextPageFlag:(int)nextPageFlag{
    
    // get method with parameters required in url
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:[NSURL URLWithString:url]];
    [request setHTTPMethod:@"GET"];
    [request setValue:DEVICETOKEN forHTTPHeaderField:@"device-token"];
    [request setValue:CLIENTNAME forHTTPHeaderField:@"client-name"];
    [request setValue:COUNT forHTTPHeaderField:@"count"];
    if (nextPageFlag) {
        [request setValue:nextPageValue forHTTPHeaderField:@"page"];
    }
    nextPage = nextPageFlag;
    
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    [[session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        // when performing UI changes, its should be done on a main thread
        [self performSelectorOnMainThread:@selector(fetchedData:)
                               withObject:data waitUntilDone:YES];
    }] resume];
    
}

- (void)fetchedData:(NSData *)responseData {
    //parse out the json data
    NSError* error;
    NSDictionary *dict = [NSJSONSerialization
                          JSONObjectWithData:responseData
                          options:kNilOptions
                          error:&error];
    if (!nextPage) {
    
        NSArray *groupArray = [dict valueForKey:@"groups"];
        cardArray = [[[groupArray objectAtIndex:0] valueForKey:@"cards"] mutableCopy];
        nextPageValue = [[groupArray objectAtIndex:0] valueForKey:@"nextPage"];
        
        [self.collectionView reloadData];
        
        // When fetching for next set of shots
    }else{
        
        NSArray *groupArray = [dict valueForKey:@"groups"];
        NSMutableArray *nextCardArray = [[NSMutableArray alloc]init];
        nextCardArray = [[[groupArray objectAtIndex:0] valueForKey:@"cards"] mutableCopy];
        
        if ([nextCardArray count] > 0) {
            NSMutableArray *indexPaths = [NSMutableArray new];
            
            for (NSInteger i = 0; i < [nextCardArray count]; i++) {
                
                [indexPaths addObject:[NSIndexPath indexPathForRow:i inSection:0]];
                [cardArray addObject:[nextCardArray objectAtIndex:i]];
            }
            
        [UIView setAnimationsEnabled:NO];
        [self.collectionView performBatchUpdates:^{
            [self.collectionView insertItemsAtIndexPaths:indexPaths];
        } completion:^(BOOL finished) {
            NSLog(@"Done");
            [UIView setAnimationsEnabled:YES];
        }];
        
        }
    }

}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark <UICollectionViewDataSource>


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
   // NSLog(@"Count = %lu",(unsigned long)[cardArray count]);
    return [cardArray count];
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *identifier = @"Cell";
    
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    
    UIImageView *recipeImageView = (UIImageView *)[cell viewWithTag:100];
    UILabel *heartCount = (UILabel*) [cell viewWithTag:101];
    
    // to maintain the UI with different screen sizes
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    CGFloat screenWidth = screenRect.size.width;
    float cellWidth = 0.0;
    NSString *deviceType = @"";
    
    
    // for iPad
    if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ) {
        // Make sure it match storyboard identifier for iPad cell
        cellWidth = screenWidth / 6.0 + 7;
        deviceType = @"large";
    }
    //iPhone device
    else {
        cellWidth = screenWidth / 3.0 - 8;
        deviceType = @"medium";
    }
    
    
    cell.backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"photo-frame.png"]];
    
    NSDictionary *dict = [cardArray objectAtIndex:indexPath.row];
    NSDictionary *shotCardDict = [dict valueForKey:@"shotCardData"];
    
    NSDictionary *shotThumbnailDict = [shotCardDict valueForKey:@"shotThumbnail"];
    
    NSString *hc = [shotCardDict valueForKey:@"heartCount"];
    
    heartCount.text = [NSString stringWithFormat:@"%@",hc];
    
    // Create a queue for the operations
    dispatch_queue_t queue = dispatch_queue_create("shotList", NULL);
    
    
    // Start getting the data in the background
    dispatch_async(queue, ^{
        NSData* photoData = [NSData dataWithContentsOfURL:[NSURL URLWithString:[shotThumbnailDict valueForKey:deviceType]]];
        UIImage* image = [UIImage imageWithData:photoData];
        
        // Once we get the data, update the UI on the main thread
        dispatch_sync(dispatch_get_main_queue(), ^{
            recipeImageView.image = image;
            recipeImageView.frame = CGRectMake(3, 3, cellWidth - 6, 141.0);
        });
    });
    
    // send request for more shots
    
    if (indexPath.item == [cardArray count] - 4) {
        [self sendRequest:FEEDURL withNextPageFlag:1];
    }
    
    return cell;
}

// to maintain distance of cells from edges (top,left,bottom,right)
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    
    if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ) {
        // Make sure it match storyboard identifier for iPad cell
        return UIEdgeInsetsMake(15 , 15, 15, 15);
    }
    else { //iPhone device
        return UIEdgeInsetsMake(8, 4, 0, 0);
    }
    
}


#pragma mark <UICollectionViewDelegate>


-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSDictionary *dict = [cardArray objectAtIndex:indexPath.row];
    NSDictionary *shotCardDict = [dict valueForKey:@"shotCardData"];
    
    NSDictionary *shotVideolDict = [shotCardDict valueForKey:@"play"];
    
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
    
    VideoViewController *VideoVC = [storyboard instantiateViewControllerWithIdentifier:@"VideoVC"];
    VideoVC.videoString = [shotVideolDict valueForKey:@"mp4"];
    
    [self.navigationController pushViewController:VideoVC animated:YES];
}

- (CGSize)collectionView:(UICollectionView *)collectionView
                  layout:(UICollectionViewLayout*)collectionViewLayout
  sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    CGFloat screenWidth = screenRect.size.width;
    
    if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ) {
        
        float cellWidth = screenWidth / 6.0 + 7;
        CGSize size = CGSizeMake(cellWidth, 147.0);
        return size;
        
    }
    else { //iPhone device
        
        float cellWidth = screenWidth / 3.0 - 8;
        CGSize size = CGSizeMake(cellWidth, 147.0);
        return size;
    }
    
    return CGSizeZero;
    
}

@end
