//
//  MainTabBarController.h
//  Kamcord_Sample
//
//  Created by Mayank Mathur on 9/6/16.
//  Copyright © 2016 Mayank Mathur. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainTabBarController : UITabBarController

@end
