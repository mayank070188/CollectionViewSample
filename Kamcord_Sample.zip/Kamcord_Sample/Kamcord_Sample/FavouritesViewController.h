//
//  FavouritesViewController.h
//  Kamcord_Sample
//
//  Created by Mayank Mathur on 8/20/16.
//  Copyright © 2016 Mayank Mathur. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FavouritesViewController : UICollectionViewController{
    
    NSDictionary *cardDictionary;
    
    NSString *nextPageValue;
    int nextPage;
    
}

@property (nonatomic, retain) NSMutableArray *cardArray;

-(void)sendRequest:(NSString*)url withNextPageFlag:(int)nextPageFlag;

@end
