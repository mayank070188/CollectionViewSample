//
//  VideoViewController.h
//  Kamcord_Sample
//
//  Created by Mayank Mathur on 8/21/16.
//  Copyright © 2016 Mayank Mathur. All rights reserved.
//

#import <UIKit/UIKit.h>
@import AVFoundation;
@import AVKit;

@interface VideoViewController : UIViewController{
    AVPlayerViewController *playerViewController;
    
}

@property (nonatomic, strong) NSString *videoString;

@end
